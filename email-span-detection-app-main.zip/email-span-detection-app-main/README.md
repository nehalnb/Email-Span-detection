# Email-Spam-Detecting-ML-Classifier

### The Jupyter notebook contains the report followed by the code.

In this paper, we build a spam detector using 4 Machine Learning models and evaluate them with test data using different performance metrics used. The dataset we used was from a shuffled sample of email subjects and bodies containing both spam and ham emails in different proportions, which we converted into lemmas. As per our analysis, Naive Bayes model and Random Forest models worked well for spam detection, whereas SVM performed the poorest among the 4 models.